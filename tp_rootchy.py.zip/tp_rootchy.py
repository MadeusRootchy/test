from random import randrange
chans=5
nonb1 = randrange(0,500)
while chans > 0:
    nonb2 = input("tanpri ,chwazi yon nonb : ")
    while not nonb2:
        nonb2 = input("tanpri,chwazi yon nonb : ")
    nonb2 = int(nonb2)
    if nonb2 != nonb1:
        if nonb2 > nonb1: 
            print("dezole,repons ou an pi gran ke nimewo ganyan an...")
        if nonb2 < nonb1:
            print("dezole,repons ou an pi piti ke nimewo ganyan an...")

        chans = chans - 1 
    else:
        print("bravo,ou genyen") 
        break  
