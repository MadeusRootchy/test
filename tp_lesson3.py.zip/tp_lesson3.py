
class Machin:
    kawoutchou = 4
    


    def __init__(self): 
        self.koule = "nwa"
        self.model = "toyota"
        self.pwopriyete = "Lub"
        self.gaz = 0 #lit gaz
        self._tente = False
        self.ane = 2012
        self.vites = 0 #KM/H
        self._pri = 170000 #goud
        self.compte = 0
    
    def akselere(self):
        if  self.gaz > 0 :
            self.vites =self.vites + 34
            if self.gaz>=14:
                self.gaz =self.gaz - 14
            else:
                self.gaz = 0    
            print(f"vites aktyel ou se {self.vites} km/h") 
            print(f" ou rete {self.gaz} lit gaz")
        if self.gaz<0:
            print("ou pa rete gaz anko,al fe gaz.") #tak lan vid, donk li pa akselere
            self.gaz = 0
    def frennen(self):
        if  self.vites > 0 :#toutotan machin nan an deplesman li posib poul frennen
            if self.vites>=58:
                self.vites =self.vites - 58
            else:
                self.vites = 0
            if self.gaz>=7:
                self.gaz =self.gaz - 7
            else:
                self.gaz = 0
            print(f" ou rete {self.gaz} lit gaz")
            print(f"vites aktyel ou se {self.vites} km/h")    
        else:
            print("Machin nan deja pakinn")#si vites la depi alabaz te 0,savledi machinn an pakinn

        
        
    def setvann(self,non):
        self.pwopriyete = non
    def vann(self):
        p = f"Machin nan vann pou {self._pri} goud, e se {self.pwopriyete.upper()} ki nouvo pwopriyete l."
        return p
    
    def douko(self,koule):
        self.koule = koule
        self._pri = self._pri + 200
        print(" Madam/Mesye ",(m.pwopriyete).upper(),"ou apenn chanje koule machin ou an an ",koule.title())        
        print(f"novo pri machinn nan se {self._pri}")
    
    def full(self,lit):
        
            
        if self.gaz <3500:
            if lit <=3500-self.gaz:
                self.gaz =lit 
                self.compte += 1
                for i in range(3,50000,3):
                    if  self.compte ==i:   
                        self._pri = self._pri -1000
                print(f"ou fe {lit} lit gaz pou {(750/3.785)*lit} goud ")
                print(f"nouvo pri machin nan se {self._pri}...")
            else:
                print(f"ou kafe selman {3500-self.gaz} lit gaz")
        else:
            print("Tank machin nan fuull  ...")
        print(self.compte)
            
    
    def stente(self,motif=False):
        motif = input("eskew vle tente vit yo? :")
        self._tente = motif
        
        print(f" madam/mesye {self.pwopriyete} ,rasirew ke ou gen papye otorizasyon DGI yo.")
        print("ou apenn sot tente vit yo")     


        
    def gtente(self):
        print("ou apenn sot tente vit yo")     
        print(self._tente)
        return self._tente
    def deltente(self):
        print("ou detente")
        del self._tente 
    tente = property(gtente,stente,deltente)
    def setpri(self,ppp):
        self._pri = ppp
        if self._pri< 170000:
            print(f"Machin nan komanse pedi vale madam/mesye {self.pwopriyete}...")
        if self._pri > 170000:
            print(f"Machin nan pran  vale madam/mesye {self.pwopriyete}...")
        
        
    def getpri(self):
        if self._pri< 170000:
            print(f"Machin nan komanse pedi vale madam/mesye {self.pwopriyete}...")
        if self._pri > 170000:
            print(f"Machin nan pran  vale madam/mesye {self.pwopriyete}...")
        return self._pri
        
    def delpri(self):
        print("pri a efase")
        del self._pri

    pri = property(getpri,setpri,delpri)
m = Machin()











