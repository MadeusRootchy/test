from random import choice
import pickle
import os

pseudo = input("Svp , chwazi yon epsedo pou jwet la : ")
while not pseudo:
    pseudo = input("Svp , chwazi yon epsedo pou jwet la : ")

    
help = input("Tape [H] pouw we koman jwet la jwe : ")
if help =="H" or help =="h":
    print("*** Men koman sa mache .Sou yon kontè 1,2,3. Chak moun ap montre sa yo chwazi ant papye, sizo, wòch.")
    print("***Si moun 1 an chwazi sizo pa ekzanp, epi moun 2 a chwazi wòch. moun 2 a genyen paske wòch ka kraze sizo.")
    print("***An jeneral se chak moun chwazi yon bagay, epi aprè nou analize sa k pi fò ke lòt.")
    print("***Men lòd la: - Wòch bat sizo - Sizo bat papye - Papye bat wòch")
    print("***Se yon chenn sa vle di ap toujou gen ganyan, depi moun yo pa pran menm bagay.")
print(f"Byenvini nan jwet la {pseudo} !!!")
ddd = {}
if not os.path.exists("sko"):
    sko=open("sko","wb")
    ddd={pseudo:0}
    pickle.dump(ddd,sko)
    sko.close()
else:
    sko=open("sko","rb") 
    ddd = pickle.load(sko)
    sko.close()
    if pseudo not in ddd.keys():
        ddd[pseudo] = 0    
        sko=open("sko","wb") 
        pickle.dump(ddd,sko)
        sko.close()
    


while pseudo:
    x = input("peze nenpot touch pouw kontinye jwe oubyen k pouw soti : ")
    if x == "k" or x =="K":
        break
    elif x !="k" or x!="K":
        lis = ["W","S","P"]
        chwa = choice(lis)
        opsyon = input("Svp ,chwazi yon let pami let sa yo ... [w,s,p] : ")
        opsyon = opsyon.upper()
        
        
        while opsyon != lis[0] and opsyon != lis[1] and opsyon != lis[-1]:
            opsyon = input(f"{pseudo} , ou pa dwe chwazi lot let kesa yo  [w,s,p] : ")
            opsyon = opsyon.upper()
        
        if chwa ==opsyon:
            print("Pagen okenn ganyan.peze nenpot touch pouw rejwe .")


        elif chwa =="S" and opsyon =="p" or chwa =="P" and opsyon =="W" or chwa =="W" and opsyon =="S":
            print("dezole,Ou pedi!")
            sko=open("sko","rb") 
            ddd = pickle.load(sko)
            ddd[pseudo] -= 50
            if ddd[pseudo]<0:
                ddd[pseudo]=0
            sko.close()
            sko=open("sko","wb") 
            pickle.dump(ddd,sko)
            sko.close()
            print(f"ou fe {ddd[pseudo]} pwen ")
        elif chwa =="P" and opsyon =="S" or chwa =="W" and opsyon =="P" or chwa =="S" and opsyon =="w":
            print("Bravo,Ou genyen!")
            sko=open("sko","rb") 
            ddd = pickle.load(sko)
            ddd[pseudo] += 50
            if ddd[pseudo]<0:
                ddd[pseudo]=0
            sko.close()
            sko=open("sko","wb") 
            pickle.dump(ddd,sko)
            sko.close()
            print(f"ou ak {ddd[pseudo]} pwen ")
sko=open("sko","rb") 
ddd = pickle.load(sko)
sko.close()  
best_score= input("Peze [z] pouw we meye sko yo   :")
if best_score =="Z" or best_score =="z":
    n= 0
    print("men lis sko yo : ")
    for i,el in sorted(ddd.items(),key=lambda x: x[-1]):
        n+=1
        if n<len(ddd)-2:
            continue
        else:
            print(f"{i}:{el}")
print(ddd)
   
        

        
                


        
            
        

        


    